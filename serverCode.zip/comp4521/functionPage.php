<?php
	include_once('coreFunctionPage.php');
	include_once('subFunctionPage.php');	
?>
<?php
	function bookListConfirm($data) {
		$dbConn = createDbConnection();
		$userId = $data->user_id;
		$bookData = $data->book_data; // array
		$arrSize = count($data->book_data);
		$addedTime = $data->added_time;
		$offerType = $data->offer_type;
		
		for($i = 0; $i < $arrSize; $i++) {
			$component = explode("@", $bookData[$i]);
			$name[$i] = $component[0];
			$author[$i] = $component[1];
			$cover[$i] = $component[2];
			$iSBN[$i] = $component[3];
			if(!checkBookInfoRecord($dbConn, $iSBN[$i])) {
				$serverBookId[$i] = insertBookInfo($dbConn, $name[$i], $author[$i], $cover[$i], $iSBN[$i]);
				$serverBookId[$i] = insertOwnerBookInfo($dbConn, $serverBookId[$i], $userId, $addedTime, $offerType);
			} else {
				$serverBookId[$i] = findBookInfo($dbConn, $iSBN[$i]);
				if(!checkOwnerBookInfo($dbConn, $serverBookId[$i], $userId, $offerType))
					$serverBookId[$i] = insertOwnerBookInfo($dbConn, $serverBookId[$i], $userId, $addedTime, $offerType);
				else 
					$serverBookId[$i] = updateOwnerBookInfo($dbConn, $serverBookId[$i], $userId, $addedTime, $offerType);
			}
		}
		return $serverBookId;
	}
	
	// do this later
	/*
	function deleteBook($data) {
		$dbConn = createDbConnection();
		$serverBookId = $data->server_book_id;//need
		$userId = $data->user_id;//need
		$arrSize = count($serverBookId);
		for ($i = 0; $i < $arrSize; $i++) {
			$sql = "DELETE FROM owner_book_info WHERE server_book_id = $serverBookId AND user_id = $userId";
			$result = $dbConn->query($sql);
		}
		//return 
	}
	*/
	function deleteBook($data) {
		$dbConn = createDbConnection();
		$serverBookId = $data->book_id;//need
		$userId = $data->user_id;//need
		$tableName = OwnerBookInfo::$DATABASE_TABLE_NAME;
		
		$sql = "SELECT server_book_id, user_id FROM $tableName WHERE server_book_id = $serverBookId AND user_id = '$userId'";
		$result = $dbConn->query($sql);
		if($result);
			//echo "Succeed for finding the book<br>";
		else
			echo "Fail for finding the book<br>".mysqli_error($dbConn)."<br>";
		$mysqlNumRows = $result->num_rows;
		
		if($mysqlNumRows) {
			$sql = "DELETE FROM $tableName WHERE server_book_id = $serverBookId AND user_id = '$userId'";
			$result = $dbConn->query($sql);
			
			if($result);
			//echo "Succeed for deleting the book<br>";
			else
				echo "Fail for deleting the book<br>".mysqli_error($dbConn)."<br>";
			
			echo "Success for deleting the book.<br>";
			
		} else //cannot find the book
			echo "Fail for deleting the book.<br>";
		
	}
	
	function changeUsername($data) {
		$dbConn = createDbConnection();
		$userId = $data->user_id; // need
		$newUsername = $data->newUsername; // need
		$tableName = UserInfo::$DATABASE_TABLE_NAME;
		
		$sql = "SELECT user_id FROM $tableName WHERE user_id = '$userId'";
		$result = $dbConn->query($sql);
		if($result);
			//echo "Succeed for finding the user ID<br>";
		else
			echo "Fail for finding the user ID<br>".mysqli_error($dbConn)."<br>";
		$mysqlNumRows = $result->num_rows;
		
		if($mysqlNumRows) {
			$sql = "UPDATE $tableName SET name = '$newUsername' WHERE user_id = '$userId'";
			$result = $dbConn->query($sql);
			
			if($result);
			//echo "Succeed for changing the username<br>";
			else
				echo "Fail for changing the username<br>".mysqli_error($dbConn)."<br>";
			
			echo "Success for changing the username.<br>";
		} else //cannot find the username
			echo "Fail for changing the username.<br>";
		
	}
	
	function changeBookStatus($data) {
		$dbConn = createDbConnection();
		$userId = $data->user_id;//need
		$serverBookId = $data->book_id;//need
		$targetStatus = $data->target_status;//need
		$tableName = OwnerBookInfo::$DATABASE_TABLE_NAME;
		
		$sql = "SELECT server_book_id, user_id FROM $tableName WHERE server_book_id = $serverBookId AND user_id = '$userId'";
		$result = $dbConn->query($sql);
		if($result);
			//echo "Succeed for finding the book status<br>";
		else
			echo "Fail for finding the user ID<br>".mysqli_error($dbConn)."<br>";
		$mysqlNumRows = $result->num_rows;
		
		if($mysqlNumRows) {
			$sql = "UPDATE $tableName SET offer_type = '$targetStatus' WHERE server_book_id = $serverBookId AND user_id = '$userId'";
			$result = $dbConn->query($sql);
			
			if($result);
			//echo "Succeed for changing the book status<br>";
			else
				echo "Fail for changing the book status<br>".mysqli_error($dbConn)."<br>";
			
			echo "Success for changing the book status.<br>";
		} else //cannot find the book status
			echo "Fail for changing the book status.<br>";
			
	}
	/*
	function getAListOfBooks($data) {
		$dbConn = createDbConnection();
		$userId = $data->user_id;//need
		$sql = "SELECT * FROM book_info WHERE user_id != '$userId'";
		$result = $dbConn->query($sql);
		
		while($row = $result->fetch_assoc()) {
			echo "Server Book ID: ".$row['server_book_id']."<br>";
			echo "Name: ".$row['name']."<br>";
			echo "Author: ".$row['author']."<br>";
			echo "Cover: ".$row['cover']."<br>";
			echo "iSBN: ".$row['iSBN']."<br><br>";
		}	
	}
	*/
	/*
	function getAListOfBooks($data) {
		$dbConn = createDbConnection();
		$userId = $data->user_id;//need
		$sql = "SELECT user_id FROM owner_book_info WHERE user_id != '$userId'";
		$result = $dbConn->query($sql);
		
		$i = 0;
		while($row = $result->fetch_assoc()) {
			//$serverBookId = $row['server_book_id'];
			//echo "UserId: ".$row['user_id']."<br>";
			$theUserId[$i] = $row['user_id'];
			$ownerBookInfoUserId = $row['user_id'];
			$sqlOwnerBookInfo = "SELECT server_book_id FROM owner_book_info WHERE user_id = '$ownerBookInfoUserId'";
			$ownerBookInfoResult = $dbConn->query($sqlOwnerBookInfo);
			//$ownerBookInfoRow = $ownerBookInfoResult->fetch_assoc();
			$j = 0;
			while($ownerBookInfoRow = $ownerBookInfoResult->fetch_assoc()) {
				$serverBookId[$j] = intval($ownerBookInfoRow['server_book_id']);
				$sqlBookInfo = "SELECT * FROM book_info WHERE server_book_id = $serverBookId ORDER BY ";
				$bookInfoResult = $dbConn->query($sqlBookInfo);
				$bookInfoRow = $bookInfoResult->fetch_assoc();
			
				$name[$j] = $bookInfoRow['name'];
				$author[$j] = $bookInfoRow['author'];
				$cover[$j] = $bookInfoRow['cover'];
				$iSBN[$j] = $bookInfoRow['iSBN'];
				
				$j++;
			}
			$bookInfo[$i] = array('server_book_id' => $serverBookId,
											'name' => $name,
											'author' => $author,
											'cover' => $cover,
											'isbn' => $iSBN);
			$i++;
		}
		$list = array('user_id' => $theUserId,
					 'book_info' => $bookInfo);
				
		return $list;
	}
	*/
	
	function getAListOfBooks($data) {
		$dbConn = createDbConnection();
		$userId = $data->user_id;//need
		
		$sql = "SELECT * FROM book_info, owner_book_info WHERE user_id != '$userId' AND book_info.server_book_id = owner_book_info.server_book_id ORDER BY book_info.name ASC";
		$result = $dbConn->query($sql);
		$i = 0;
		while($row = $result->fetch_assoc()) {
			$serverBookId[$i] = intval($row['server_book_id']);
			$theUserId[$i] = $row['user_id'];
			$numOfBook[$i] = intval($row['num_of_book']);
			$numOfBookAvailable[$i] = intval($row['num_of_book_available']);
			$addedTime[$i] = $row['added_time'];
			$offerType[$i] = $row['offer_type'];
			$name[$i] = $row['name'];
			$author[$i] = $row['author'];
			$cover[$i] = $row['cover'];
			$iSBN[$i] = $row['iSBN'];
			
			$i++;
		}
	
		 $list = array('server_book_id' => $serverBookId,
								'user_id' => $theUserId,
							'num_of_book'=> $numOfBook,
				'num_of_book_available' => $numOfBookAvailable,
							'added_time' => $addedTime,
							'offer_type' => $offerType,
								'name' => $name,
								'author' => $author,
								'cover' => $cover,
								'isbn' => $iSBN);
				
		$originalStr = backToOriginalString($list);
		return $originalStr;
	}
	
	function getAListOfUsers($data) {
		$dbConn = createDbConnection();
		$userId = $data->user_id;
		$sql = "SELECT * FROM user_info WHERE user_id != '$userId'";
		$result = $dbConn->query($sql);
		
		$i = 0;
		while($row = $result->fetch_assoc()) {
			$theUserId[$i] = $row['user_id'];
			$name[$i] = $row['name'];
			$phone[$i] = $row['phone'];
			$userSetting[$i] = $row['user_setting'];
			
			$i++;
		}	
		$list = array('user_id' => $theUserId,
						 'name' => $name,
						'phone' => $phone,
				 'user_setting' => $userSetting);
				
		return $list;
	}
	
	function getAListOfBookFromTheUser($data) {
		$dbConn = createDbConnection();
		$targetUserId = $data->target_user_id;//need
		$sql = "SELECT * FROM book_info, owner_book_info WHERE user_id = '$targetUserId' AND book_info.server_book_id = owner_book_info.server_book_id ORDER BY name ASC";
		$result = $dbConn->query($sql);
		if($result);
			//echo "Succeed for changing the book status<br>";
			else
				echo "Fail for changing the book status<br>".mysqli_error($dbConn)."<br>";
		$i = 0;
		while($row = $result->fetch_assoc()) {
			$serverBookId[$i] = intval($row['server_book_id']);
			$sqlBookInfo = "SELECT * FROM book_info WHERE server_book_id = $serverBookId[$i]";
			$bookInfoResult = $dbConn->query($sqlBookInfo);
			$bookInfoRow = $bookInfoResult->fetch_assoc();
			
			$name[$i] = $bookInfoRow['name'];
			$author[$i] = $bookInfoRow['author'];
			$cover[$i] = $bookInfoRow['cover'];
			$iSBN[$i] = $bookInfoRow['iSBN'];
			
			$i++;
		}
		
		$list = array('server_book_id' => $serverBookId,
								'name' => $name,
								'author' => $author,
								'cover' => $cover,
								'isbn' => $iSBN);
		//$done = json_encode($test);
		//echo $done;
		$originalStr = backToOriginalString($list);
		return $originalStr;
	}
?>